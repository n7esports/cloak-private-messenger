---
name: Cyber-Stealth Minimalist
colors:
  surface: '#131315'
  surface-dim: '#131315'
  surface-bright: '#39393b'
  surface-container-lowest: '#0e0e10'
  surface-container-low: '#1c1b1d'
  surface-container: '#201f22'
  surface-container-high: '#2a2a2c'
  surface-container-highest: '#353437'
  on-surface: '#e5e1e4'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#e5e1e4'
  inverse-on-surface: '#313032'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#45dfa4'
  on-secondary: '#003825'
  secondary-container: '#00bd85'
  on-secondary-container: '#00452e'
  tertiary: '#ffb2b7'
  on-tertiary: '#67001b'
  tertiary-container: '#ff7886'
  on-tertiary-container: '#780021'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#68fcbf'
  secondary-fixed-dim: '#45dfa4'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#005137'
  tertiary-fixed: '#ffdadb'
  tertiary-fixed-dim: '#ffb2b7'
  on-tertiary-fixed: '#40000d'
  on-tertiary-fixed-variant: '#92002a'
  background: '#131315'
  on-background: '#e5e1e4'
  surface-variant: '#353437'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 2rem
    fontWeight: '600'
    lineHeight: 2.5rem
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
  headline-md:
    fontFamily: Inter
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
  headline-sm:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
  body-lg:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
  body-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
  code-lg:
    fontFamily: JetBrains Mono
    fontSize: 0.9375rem
    fontWeight: '500'
    lineHeight: 1.375rem
  code-md:
    fontFamily: JetBrains Mono
    fontSize: 0.8125rem
    fontWeight: '500'
    lineHeight: 1.25rem
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: 1rem
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: 0.875rem
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

The design system establishes a high-precision, tactical security environment built for extreme privacy, zero-trust cryptographic verification, and operational resilience. It speaks directly to security architects, cypherpunks, operational intelligence teams, and privacy-conscious operators who treat communication as a critical vulnerability surface.

The emotional signature is cool, deliberate, impenetrable, and mathematically precise. The interface avoids frivolous ornamentation, prioritizing immediate situational awareness, verified payload status, and non-distracting dark-room ergonomics. 

Visually, the system combines **Minimalism** with an **Industrial Tactical Cyber aesthetic**:
- Razor-sharp structural discipline defined by hairline dividers and precise grid snapping.
- Deep obsidian and zinc tonal stacking that reduces OLED eye fatigue and eliminates display light bleed.
- Monospaced cryptographic readouts that convey absolute algorithmic transparency.
- Focused, luminescent telemetry accents in emerald and alert crimson that command decisive action without visual noise.

## Colors

The palette is engineered specifically for low-light, high-contrast operational scenarios with strict state hierarchy.

### Core Tones
- **Base Canvas (Obsidian Zinc - `#09090b`)**: The absolute bedrock background. Absorbs light and provides deep zero-contrast negative space.
- **Surface Elevation 1 (Dark Zinc - `#18181b`)**: Structural sidebars, tool panels, split-pane rails, and container trays.
- **Surface Elevation 2 (Overlay Zinc - `#27272a`)**: Floating context panels, active inspect drawers, hover states, and input field backgrounds.
- **Hairline Structural Borders (`#3f3f46` at 40-70% opacity)**: Precision structural edges demarcating encrypted channels, packet logs, and message panes.

### Signal Accents
- **Primary / Verified Signal (Cyber Emerald - `#10b981`)**: Denotes active cryptographic handshakes, valid fingerprint matches, zero-knowledge proofs, and secure transmission pathways. Emits a controlled micro-glow when active.
- **Secondary / Telemetry Signal (Mint - `#34d399`)**: Secondary metadata indicators, low-priority confirmations, read receipts, and system uptime markers.
- **Tertiary / Hazard Signal (Alert Crimson - `#f43f5e`)**: MitM warnings, invalid signature exceptions, burn/ephemeral countdowns, session self-destruct timers, and connection drops.
- **Text & Glyph Hierarchy**:
  - `text-high-contrast`: `#fafafa` (Primary payloads, active keys, active labels)
  - `text-medium`: `#a1a1aa` (Timestamps, protocol details, secondary labels)
  - `text-muted`: `#71717a` (Empty state placeholders, disabled cryptographic controls)

## Typography

The type system implements a strict functional dichotomy: **Inter** handles narrative clarity and conversational payloads, while **JetBrains Mono** provides cryptographic verification, telemetry metrics, protocol metadata, and interface micro-labels.

### Typographic Directives
- **Payload vs Telemetry Separation**: Decrypted conversation text is rendered in `body-md` / `body-lg` using Inter with crisp line-height for rapid scanning. Identity signatures, public keys (e.g., `0x7F...3B9`), SHA-256 digests, ephemeral session counters, and latency figures must strictly render in `code-*` styles using JetBrains Mono.
- **Label Formatting**: All system flags, badge markers, encryption state tags, and header caps are set in `label-caps` with uppercase transformation and a letter-spacing value of `0.08em`.
- **Numerics**: Monospace tabular figures are enforced across all counters, packet gauges, and message timestamps to prevent layout jitter during real-time telemetry streaming.

## Layout & Spacing

The layout is built upon a dense, modular split-pane workbench optimized for intense information density and zero horizontal waste.

### Grid & Layout Structure
- **Workbench Layout (Desktop / Operator View)**: A 3-tier persistent column structure:
  - Tactical Rail (56px fixed): Identity selector, vault switch, global killswitch.
  - Channel / Thread Stream (320px fixed): Encrypted session list, search filter, ratcheted key status.
  - Active Transmission Workspace (Fluid): Cryptographic transcript, active key inspector, compose console.
  - Contextual Telemetry Drawer (360px collapsible): Session audit log, protocol handshake proofs, key expiration sliders.
- **Compact View (Mobile)**: Linear drill-down view with sticky top-level security indicators (verified badge and emergency purge button always in safe areas).

### Rhythms & Gaps
Layout components conform strictly to an exact 4px sub-pixel grid unit:
- Channel items and message rows utilize `space-sm` (8px) internal padding for high vertical density.
- Tactical metadata strips (latency, protocol, ratcheting sequence) utilize `space-xs` (4px) micro-gaps.
- Component structural bounding boxes maintain `space-md` (12px) separating lines.

## Elevation & Depth

This design system avoids traditional drop shadows and blur-heavy skeuomorphism, which simulate ambient lighting unnatural to a tactical terminal. Instead, depth is articulated through **Tonal Stacking**, **Fine Structural Borders**, and **Active Luminescence**.

### Surface Hierarchy
1. **Layer 0 (Canvas Base)**: `#09090b` (Primary viewport ground).
2. **Layer 1 (Recessed/Divided Structural Shells)**: `#18181b` framed with a 1px solid border of `#27272a`.
3. **Layer 2 (Interactive Floating Modules / Menus)**: `#27272a` with a 1px solid border of `#3f3f46`.
4. **Layer 3 (Overlays & Verification Modals)**: `#18181b` backed by an 85% opacity `#000000` shroud, bounded by `#52525b`.

### Active Luminescence
- Shadows are reserved strictly for illuminated states:
  - **Verified / Connected State**: `box-shadow: 0 0 12px -2px rgba(16, 185, 129, 0.35)`
  - **MitM / Breach State**: `box-shadow: 0 0 14px -2px rgba(244, 63, 94, 0.45)`
- Inactive elements receive flat 1px outlines (`#27272a`), giving the interface a milled, instrument-panel aesthetic.

## Shapes

The interface embraces a machined, surgical profile. Corners are subtly eased to prevent visual fatigue while retaining a crisp, structured appearance.

- **Standard Base Radii (`roundedness: 1` / 4px)**: Applied to text input fields, message bubbles, cryptographic chip tags, status pills, and panel buttons.
- **Larger Radii (`rounded-lg` / 8px)**: Applied exclusively to major modal windows, ephemeral verification popovers, and QR code verification viewports.
- **Never Fully Rounded**: Capsule (full pill) shapes are strictly prohibited except for binary operational toggle dots. Identity avatars use 4px squircle forms with a 1px outer ring rather than standard circular avatars to reinforce the tactical cyber aesthetic.

## Components

### Buttons
- **Primary / Tactical Action**: Solid `#10b981` background, `#09090b` bold JetBrains Mono typography. On hover: `#34d399` with `box-shadow: 0 0 12px rgba(16, 185, 129, 0.4)`. Focus state: 1px offset outline in `#10b981`.
- **Secondary / Ghost Operation**: Transparent background, 1px solid `#27272a` border, `#fafafa` typography. Hover: `#18181b` background, border `#52525b`.
- **Critical / Emergency Action (Burn/Purge)**: 1px solid `#f43f5e`, transparent background, `#f43f5e` text. Hover: `#f43f5e` background with `#09090b` text and alert glow.

### Cryptographic Chips & Status Tags
- **Telemetry Chips**: Height 20px, 4px border-radius, `#18181b` background, 1px solid `#27272a`. Typography in `code-sm`.
- **Handshake Verification Tag**: Prepends an emerald beacon dot (5px) with `0 0 6px #10b981` pulse animation, showing status `E2EE: 256-BIT RATIFIED`.

### Input Fields & Compose Bar
- **Terminal Inputs**: Surface `#18181b`, 1px solid `#27272a`. Typography in `body-md` (Inter) with placeholder in `text-muted`.
- **Active Focus**: Border transitions to `#10b981` with an inner micro-highlight. Never uses browser default halos.
- **Action Accessories**: Right-aligned monospace byte counter, ephemeral timer selector (e.g., `[5m ⏷]`), and file encryption badge.

### Message Cells & Transcripts
- **Incoming Transmission**: Left-aligned, `#18181b` background with 1px solid `#27272a`. Header displays sender key fingerprint in `code-sm` (`#71717a`).
- **Outgoing Secure Transmission**: Right-aligned, `#10b981` at 8% opacity fill with 1px solid `#10b981` at 30% opacity. Text in `#fafafa`. Micro metadata in `code-sm` displaying delivery ratchet receipt (`✓✓`).

### Checkboxes & Binary Selectors
- **Toggles & Selectors**: Custom square 14px boxes, `#09090b` background with 1px solid `#3f3f46`. Checked state displays a solid `#10b981` core with crisp inset.

### Specialized Security Components
- **Key Fingerprint Visualizer**: Segmented matrix displaying grouped hex blocks (`4A9F 001B C72E ...`) with copy-to-clipboard single-click triggers and QR cross-verification overlay.
- **Ephemeral Session Countdown Bar**: A 2px high active indicator line pinned to the base of self-destructing message cells, depleting linearly in `#f43f5e`.